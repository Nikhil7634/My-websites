var a = document.getElementById('nav');
var b = document.getElementById('menu');

b.onclick = function(){
  a.classList.toggle("slide");
}
